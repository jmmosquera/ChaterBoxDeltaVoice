package com.example.damjmm.aadfirebase;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    private FirebaseAuth autenticadorFirebase;
    private FirebaseUser user;

    private FirebaseDatabase database;
    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }

    private void init(){
        //autentificar("master@ieszaidinvergeles.org", "123456");

        database = FirebaseDatabase.getInstance();
        autenticadorFirebase = FirebaseAuth.getInstance();
        reference = database.getReference();
        //autentificar("master@ieszaidinvergeles.org", "123456");
        //crearUsuario("abc@abc.es", "abc123");
        //guardarItem();
        leer();

    }

    private void autentificar(String email, String password){
        autenticadorFirebase = FirebaseAuth.getInstance();
        //firebaseAuth.signInWithEmailAndPassword(email, password);
        autenticadorFirebase.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    user = autenticadorFirebase.getCurrentUser();
                    //crearUsuario("bien@bienesta.com", "123455");
                    Log.v("TAGX", "onComplete"+user.getUid()+" "+ user.getEmail());
                }else{
                    user = null;
                    //crearUsuario("mal@malesta.com", "33233433");
                }
            }
        });
    }

    private void crearUsuario(String email, String password) {
        autenticadorFirebase.createUserWithEmailAndPassword(email, password).
                addOnCompleteListener(this,
                        new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = task.getResult().getUser();
                                    Log.v("TAGXYZ", user.getUid()+" "+user.getEmail()+"");
                                    //Guardar en preferencias compartidas la informacion pertinente, o hacerlo más adelante
                                    //user.getEmail(); user.getUid();
                                    //guardarUsuario(user);
                                    guardarItem(user);
                                } else {
                                    task.getException();
                                    Log.v("TAGX", task.getException().toString());
                                }
                            }
                        });
    }


    private void guardarUsuario(FirebaseUser user){

        Map<String, Object> saveUser = new HashMap<>();
        saveUser.put("/user/" + user.getUid(), user.getEmail());
        reference.updateChildren(saveUser);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Object value = dataSnapshot.getValue();
                String key = dataSnapshot.getKey();
                Log.w("TAGX", value.toString() + key);
            }
            @Override
            public void onCancelled(DatabaseError error) {
                Log.v("TAGX", ""+error.toException());
            }
        });
    }

    private void guardarItem(FirebaseUser user){
        Item i = new Item("2", "nombre", "mensaje");
        Map<String, Object> saveItem = new HashMap<>();
        String key = reference.child("item").push().getKey();
        saveItem.put("/" + user.getUid()+key +"/item/"+ "/", i.toMap());
        reference.updateChildren(saveItem);
    }

    private void leer() {

        /*ValueEventListener postListener = new ValueEventListener() {
            @Override
            public void OnDataChanged(DataSnapshot dataSnapshot) {
                Item item = dataSnapshot.getValue(Item.class);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }


        };
        query.addValueEventListener(postListener);*/

        Query query = reference.child("item");
        query.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Item item = dataSnapshot.getValue(Item.class);
                Log.v("TAGX", "loadPost:onDataAdded:" + item.toString());
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



    @Override
    public void onStart() {
        super.onStart();
        //firebaseAuth.addAuthStateListener(firebaseAuthListener);
    }
    @Override
    public void onStop() {
        super.onStop();
    }
}


//La aplicacion siempre conecta con el google Cloud

//Al intentar loguear puede darnos más de una respuesta

//Siempre es posible crear usuarios nuevos

